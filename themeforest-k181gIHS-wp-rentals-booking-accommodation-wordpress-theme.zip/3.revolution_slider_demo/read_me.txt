WP Rentals Theme supports 1 click demo import. 
Help: https://help.wprentals.org/article/demo-setup-with-1-click-demo-import/

MUST HAVE Server Requirements:

Server PHP 5.5 minimum!!
max_execution_time 180
memory_limit 128M
post_max_size 48M
upload_max_filesize 49M

We recommend importing only 1 demo zip for correct demo setup. 

If you wish a different demo, clear database and import the new demo after.

How to import:

Find the demo import zip in theme pack, demo_content folder. 
Go go Theme Options - WpRentals import
Select the demo zip and click Import. 


Notes:

*After you import the content you may need to edit certain pages and assign the correct category id for some shortcodes. 

**Make sure that for Ultimate Addons these settings are done: Ultimate - Scripts & Styles - 
Optimized CSS - ON
Optimized JS - ON


For client support please open a ticket at http://support.wpestate.org/

