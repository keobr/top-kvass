Thank you for buying Wavio theme!

If you have questions for installing and using the theme, please visit documentation:
https://peerduck.com/docs/wavio


******************
Theme installation
******************

Standard Theme Installation:
1) Use wavio.zip file to upload new theme in Appearance -> Themes -> Add new.
2) Install all required plugins and activate them.
3) You can import the demo content for a quick site setup.
   Tools -> Demo Content Install. Will install all demo content for the site.

Notice: if you want to use a child-theme, you can also upload the file wavio-child.zip in addition to the main Wavio theme.


*******
Support
*******

You can contact us if you have any questions at:
https://peerduck.com/help
https://themeforest.net/user/peerduckthemes
